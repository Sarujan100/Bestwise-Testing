import React from 'react'
import {Products} from '@/compone'
const productsInventory = () => {
  return (
    <div>
      
    </div>
  )
}

export default productsInventory
