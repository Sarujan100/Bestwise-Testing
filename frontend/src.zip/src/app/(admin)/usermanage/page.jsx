import { UsersManagement } from './users-management';

export default function UsersPage() {
  return <UsersManagement />;
}