import React from 'react'
import Managerproducs from '../../components/manageproducts/page'
const page = () => {
  return (
    <div>

        <Managerproducs/>
    </div>
  )
}

export default page